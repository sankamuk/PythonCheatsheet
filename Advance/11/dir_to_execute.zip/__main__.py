print("Directory executes!!!")
